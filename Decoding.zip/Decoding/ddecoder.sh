#!/usr/bin/env bash
#
php ~/Documents/TOOLS/Scripts-Alex/PHP-Scripts/Decoding/desktop-decoder.php
